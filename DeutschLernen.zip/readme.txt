﻿code nay fix loi không play duoc youtube vi bi Invisible
code cu chi play duoc 2-3s la bi pause lại không play được.
kĩ thuật: Change VIDEO_ID và cho chạy Video luôn. không cần phải load lại layout nữa. Vừa nhanh vừa không phải request nhiều tới server.